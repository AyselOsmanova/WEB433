
$(document).ready(function(){

    $(".dropdown-menu #teams-menu").on("click",function(event){
        event.preventDefault();
        $('#data').empty();
         var heading='<h3>Teams</h3>';

        $.ajax({
            url: "https://lit-refuge-67160.herokuapp.com/teams", 
            type: "GET",
            contentType: "application/json"
        })
        .done(function (teams) {
            $("#data").append(heading).append(JSON.stringify(teams));                
            
        })
        .fail(function (err) {
            console.log("error: " + err.statusText);
        });
    });

    $(".dropdown-menu #employees-menu").on("click",function(event){
        event.preventDefault();

        $('#data').empty();
         var heading='<h3>Employees</h3>';

        $.ajax({
            url: "https://lit-refuge-67160.herokuapp.com/employees", 
            type: "GET",
            contentType: "application/json"
        })
        .done(function (employees) {
            $("#data").append(heading).append(JSON.stringify(employees));
               
        })
        .fail(function (err) {
            console.log("error: " + err.statusText);
        });
    });

 
    $(".dropdown-menu #projects-menu").on("click",function(event){
        event.preventDefault();
        $('#data').empty();
         var heading='<h3>Projects</h3>';

        $.ajax({
            url: "https://lit-refuge-67160.herokuapp.com/projects", 
            type: "GET",
            contentType: "application/json"
        })
        .done(function (projects) {
            $("#data").append(heading).append(JSON.stringify(projects));
            
             
                
               
                       
            
        })
        .fail(function (err) {
            console.log("error: " + err.statusText);
        });
    });

    // POSITIONS BUTTON
    $(".dropdown-menu #positions-menu").on("click",function(event){
        event.preventDefault();
      
        $('#data').empty();
         var heading='<h3>Positions</h3>';

        $.ajax({
            url: "https://lit-refuge-67160.herokuapp.com/positions", 
            type: "GET",
            contentType: "application/json"
        })
        .done(function (positions) {
            $("#data").append(heading).append(JSON.stringify(positions));
                  
        })
        .fail(function (err) {
            console.log("error: " + err.statusText);
        });

    })
})

