const mongoose = require('mongoose');

// Load the schemas
const employeeSchema = require('./models/employee.js');
const positionSchema = require('./models/position.js');
const projectSchema = require('./models/project.js');
const teamSchema = require('./models/team.js');

module.exports = function(mongoDBConnectionString){

    let Employee; 
    let Position; 
    let Project; 
    let Team; 

    return {
        connect: function(){
            return new Promise(function(resolve,reject){
                let db = mongoose.createConnection(mongoDBConnectionString);
                
                db.on('error', (err)=>{
                    reject(err);
                });
        
                db.once('open', ()=>{
                    Employee = db.model("Employee", employeeSchema);
                    Position = db.model("Position", positionSchema);
                    Project = db.model("Project", projectSchema);
                    Team = db.model("Team", teamSchema);

                    resolve();
                });
            });
        },
        getAllEmployees: function(){
            return new Promise(function(resolve,reject){

                Employee.find()
                .populate("Position") 
                .exec()
                .then((employees) => {
                    resolve(employees);
                })
                .catch((err)=>{
                    reject(err);
                });
            })
        },
        getAllEmployeesRaw: function(){
            return new Promise(function(resolve,reject){
    
                Employee.find()
                 .exec()
                .then((employees) => {
                    resolve(employees);
                })
                .catch((err)=>{
                    reject(err);
                });
            })
        },
        getEmployeeById: function(employeeId){
            return new Promise(function(resolve,reject){

                Employee.find({_id: employeeId})
                 .populate("Position") 
                .limit(1)
                .exec()
                .then((employees) => {
                    resolve(employees);
                })
                .catch((err)=>{
                    reject(err);
                });
            })
        },
        getEmployeeByIdRaw: function(employeeId){
            return new Promise(function(resolve,reject){

                Employee.find({_id: employeeId})
                   .limit(1)
                .exec()
                .then((employees) => {
                    resolve(employees);
                })
                .catch((err)=>{
                    reject(err);
                });
            })
        },
        updateEmployeeById: function (employeeId, employeeData) {
            return new Promise(function (resolve, reject) {
                if (Object.keys(employeeData).length > 0) { 
                    Employee.update({ _id: employeeId },       {
                            $set: employeeData
                        },
                        { multi: false })
                        .exec()
                        .then((data) => {
                            resolve(employeeId);
                        })
                        .catch((err) => {
                            reject(err);
                        });
                } else {
                    resolve();
                }
            });
        },
        addEmployee: function (employeeData) {
            return new Promise(function (resolve, reject) {
                
             
                var newEmployee = new Employee(employeeData);

                newEmployee.save((err,addedEmployee) => {
                    if(err) {
                        reject(err);
                    } else {
                        resolve(addedEmployee._id);
                    }
                });
            });
        },
        getAllPositions: function(){
            return new Promise(function(resolve,reject){

                Position.find()
                 .exec()
                .then((positions) => {
                    resolve(positions);
                })
                .catch((err)=>{
                    reject(err);
                });
            })
        },
        getPositionById: function(positionId){
            return new Promise(function(resolve,reject){

                Position.find({_id: positionId})
                 .limit(1)
                .exec()
                .then((positions) => {
                    resolve(positions);
                })
                .catch((err)=>{
                    reject(err);
                });
            })
        },
        updatePositionById: function (positionId, positionData) {
            return new Promise(function (resolve, reject) {
                if (Object.keys(positionData).length > 0) { 
                    Position.update({ _id: positionId }, 
                                  {
                            $set: positionData
                        },
                        { multi: false })
                        .exec()
                        .then(() => {
                            resolve(positionId);
                        })
                        .catch((err) => {
                            reject(err);
                        });
                } else {
                    resolve();
                }
            });
        },
        addPosition: function (positionData) {
            return new Promise(function (resolve, reject) {
                
              
                var newPosition = new Position(positionData);

                newPosition.save((err,addedPosition) => {
                    if(err) {
                        reject(err);
                    } else {
                        resolve(addedPosition._id);
                    }
                });
            });
        },
        getAllProjects: function(){
            return new Promise(function(resolve,reject){

                Project.find()
                 .exec()
                .then((projects) => {
                    resolve(projects);
                })
                .catch((err)=>{
                    reject(err);
                });
            })
        },
        getProjectById: function(projectId){
            return new Promise(function(resolve,reject){

                Project.find({_id: projectId})
              
                .limit(1)
                .exec()
                .then((projects) => {
                    resolve(projects);
                })
                .catch((err)=>{
                    reject(err);
                });
            })
        },
        updateProjectById: function (projectId, projectData) {
            return new Promise(function (resolve, reject) {
                if (Object.keys(projectData).length > 0) { 
                    Project.update({ _id: projectId },         {
                            $set: projectData
                        },
                        { multi: false })
                        .exec()
                        .then(() => {
                            resolve(projectId);
                        })
                        .catch((err) => {
                            reject(err);
                        });
                } else {
                    resolve();
                }
            });
        },
        addProject: function (projectData) {
            return new Promise(function (resolve, reject) {
                
                
                var newProject = new Project(projectData);

                newProject.save((err,addedProject) => {
                    if(err) {
                        reject(err);
                    } else {
                        resolve(addedProject._id);
                    }
                });
            });
        },
        getAllTeams: function(){
            return new Promise(function(resolve,reject){

                Team.find()
                 .populate("Projects") 
                .populate("Employees") 
                .populate("TeamLead") 
                .populate({ 
                    path: 'TeamLead',
                    populate: {
                      path: 'Position',
                      model: 'Position'
                    } 
                 })
                 .populate({ 
                    path: 'Employees',
                    populate: {
                    path: 'Position',
                    model: 'Position'
                    } 
                })
                .exec()
                .then((teams) => {
                    resolve(teams);
                })
                .catch((err)=>{
                    reject(err);
                });
            })
        },
        getAllTeamsRaw: function(){
            return new Promise(function(resolve,reject){

                Team.find()
                 .exec()
                .then((teams) => {
                    resolve(teams);
                })
                .catch((err)=>{
                    reject(err);
                });
            })
        },
        getTeamById: function(teamId){
            return new Promise(function(resolve,reject){

                Team.find({_id: teamId})
                .populate("Projects") 
                .populate("Employees") 
                .populate("TeamLead") 
                .populate({ 
                    path: 'TeamLead',
                    populate: {
                    path: 'Position',
                    model: 'Position'
                    } 
                })
                .populate({ 
                    path: 'Employees',
                    populate: {
                    path: 'Position',
                    model: 'Position'
                    } 
                })
                .limit(1)
                .exec()
                .then((teams) => {
                    resolve(teams);
                })
                .catch((err)=>{
                    reject(err);
                });
            })
        },
        getTeamByIdRaw: function(teamId){
            return new Promise(function(resolve,reject){

                Team.find({_id: teamId})
                .limit(1)
                .exec()
                .then((teams) => {
                    resolve(teams);
                })
                .catch((err)=>{
                    reject(err);
                });
            })
        },
        updateTeamById: function (teamId, teamData) {
            return new Promise(function (resolve, reject) {
                if (Object.keys(teamData).length > 0) { 
                    Team.update({ _id: teamId }, 
                        {
                            $set: teamData
                        },
                        { multi: false })
                        .exec()
                        .then(() => {
                            resolve(teamId);
                        })
                        .catch((err) => {
                            reject(err);
                        });
                } else {
                    resolve();
                }
            });
        },
        addTeam: function (teamData) {
            return new Promise(function (resolve, reject) {
             
                var newTeam = new Team(teamData);

                newTeam.save((err,addedTeam) => {
                    if(err) {
                        reject(err);
                    } else {
                        resolve(addedTeam._id);
                    }
                });
            });
        },
    }

}