export class EmployeeRaw
{
    _id:String;
    FirstName:String;
    LastName:String;
    AddressStreet:String;
    AddressState:String;
    AddressCity:String;
    AddressZip:String;
    PhoneNum:String;
    Extension:Number;
    Position:String;
    HireDate:String;
    SalaryBonus:Number;
    __v:Number;
}